<?php

namespace App\Http\Controllers;

use Alert;
use App\Barang;
use Illuminate\Http\Request;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('barang.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validasi form yg dikirim agar sesuai dengan aturan dan kebutuhan
        $request->validate([
            //nama input => rules
            'nama_barang' => 'required',
            'harga' => 'required',
            'stok' => 'required',
            'keterangan' => 'required',
            'file_gambar' => 'required'
        ]);

        // Ambil file yg diupload
        $file = $request->file('file_gambar');
        // Nama file yg digunakan
        $request['gambar'] = $request->nama_barang.'.'.$file->getClientOriginalExtension();
        // Simpan file di uploads/
        $file->storeAs('uploads', $request->gambar, 'public_path');


        // Tambahkan data barang berdasar form yang dikirim
        Barang::create($request->except('file_gambar'));

        Alert::success('Barang berhasil ditambahkan', 'Success');
        return redirect('home');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Cari barang yg akan diubah
        $data['barang'] = Barang::findOrFail($id);

        // Tampilkan form ubah barang beserta datanya
        return view('barang.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Validasi form yg dikirim agar sesuai dengan aturan dan kebutuhan
        $request->validate([
            //nama input => rules
            'nama_barang' => 'required',
            'harga' => 'required',
            'stok' => 'required',
            'keterangan' => 'required',
        ]);

        // Cari data barang yang akan diubah
        $barang = Barang::findOrFail($id);

        // Jika upload gambar baru
        if ($request->file_gambar) {
            // Ambil file yg diupload
            $file = $request->file('file_gambar');
            // Nama file yg digunakan
            $request['gambar'] = $request->nama_barang.'.'.$file->getClientOriginalExtension();
            // Simpan file
            $file->storeAs('uploads', $request->gambar, 'public_path');
        }

        $barang->update($request->except(['file_gambar']));

        Alert::success('Barang berhasil diubah', 'Success');
        return redirect('home');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Cari data barang yang akan dihapus
        $barang = Barang::findOrFail($id);

        $barang->delete();

        Alert::success('Barang berhasil dihapus', 'Success');
        return redirect('home');
    }
}
